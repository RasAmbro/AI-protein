print ('Hello World')
